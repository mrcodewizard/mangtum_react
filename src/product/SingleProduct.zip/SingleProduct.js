    import React, {useCallback, useEffect, useRef, useState} from "react";
    import {Link, useNavigate} from "react-router-dom";
    import {useDispatch, useSelector} from "react-redux";
    import {
        addWishlist,
        getProductCartCount,
        getRelatedProducts,
        getSingleProductDetail,
        getVendorInfo,
    } from "../store/product";
    import {AddToCart, getCartData} from "../store/newCart";
    import {getHeaderData} from "../store/home";
    import "react-image-gallery/styles/css/image-gallery.css";
    import ImageGallery from "react-image-gallery";
    import {Slide, toast, ToastContainer} from "react-toastify";
    import "react-toastify/dist/ReactToastify.css";
    // Add this to the parent component that contains the Carousel
    import "react-responsive-carousel/lib/styles/carousel.min.css";
    import SiteLoader from "../SiteLoader";
    import {fixChar} from "../utils/helper";
    
    import "swiper/css";
    import "swiper/css/navigation";
    import "swiper/css/pagination";
    import {images} from "../utils/images";
    import {Modal} from "react-bootstrap";
    
    let variantData = {};
    const SingleProduct = () => {
        const navigate = useNavigate();
        const dispatch = useDispatch();
    
        // const
        let userDetails = localStorage.getItem("userDetails");
        let data = JSON.parse(userDetails);
        let user_id = data?.ID;
        let isLogin = false;
        if (user_id) isLogin = true;
        else isLogin = false;
        const filterUrl = window.location.pathname.split("shop/").pop();
        const productSlug = filterUrl.split("/");
        const prodSlug = productSlug[2];
    
        const [modalImages, setModalImages] = useState([]);
        const [imageIndex, setImageIndex] = useState(0);
    
        // use selector
        const st = useSelector((state) => state.prodLi);
        const singleProduct = useSelector((state) => state.prodLi.singleProduct);
        const {loader, status} = useSelector((state) => state.cart);
        const {statusKey} = useSelector((state) => state.prodLi);
        const galleryI = useSelector((state) => state.prodLi.galleryimages);
        const relatedProducts = useSelector((state) => state.prodLi.related_prod);
        const inDetails = useSelector((state) => state.prodLi.productVariations);
        const userCartProductCount = useSelector((state) => state.prodLi.userCartProductCount);
        const storeInfoTab = useSelector((state) => state.prodLi.vendorInfo);
        const shippingDetails = useSelector((state) => state.prodLi.singleProduct?.product.shipping_profile);
        const wish = useSelector((state) => state.prodLi.wishlist_status);
        const cartData = useSelector((state) => state.newCart.cartData);
    
        const image = [
            {
                original: singleProduct?.product?.main_image,
                thumbnail: singleProduct?.product?.main_image,
                originalHeight: 350,
                originalWidth: 350,
                thumbnailHeight: 90,
                thumbnailWidth: 60,
            },
            ...galleryI.map((imgList) => ({
                original: imgList,
                thumbnail: imgList,
                originalHeight: 350,
                originalWidth: 350,
                thumbnailHeight: 90,
                thumbnailWidth: 60,
            })),
        ];
    
        const product_id = singleProduct?.product?.id;
        const subCateId = singleProduct?.product?.sub_ids["0"];
        let pTag = storeInfoTab?.vendor?.return_policy;
        const sanitizedText = pTag?.replace(/<[^>]+style="[^"]*"[^>]*>|&nbsp;/g, "");
        let pTagTwo = storeInfoTab?.vendor?.terms_conditions;
        const sanitizedTextTwo = pTagTwo?.replace(
            /<[^>]+style="[^"]*"[^>]*>|&nbsp;/g,
            ""
        );
        let pTagThree = storeInfoTab?.vendor?.shipping_policy;
        const sanitizedTextThree = pTagThree?.replace(
            /<[^>]+style="[^"]*"[^>]*>|&nbsp;/g,
            ""
        );
    
        // use state
        const [invId, setInvId] = useState("");
        const [stockVal, setStockVal] = useState(0);
        const [regularPrice, setRegularPrice] = useState(0);
        const [sellPrice, setSellPrice] = useState(0);
        const [selectedColor, setSelectedColor] = useState("");
        const [dbQuantity, setDbQuantity] = useState(1);
        const [prodQty, setProdQty] = useState(1);
        const [selectedAttributes, setSelectedAttributes] = useState([]);
        const [buttonShouldDisable, setButtonShouldDisable] = useState(false);
        const [selectedRadio, setSelectedRadio] = useState(
            Array(inDetails?.variation?.length).fill(false)
        );
        const [arr, setArr] = useState([]);
        const [activeTab, setActiveTab] = useState("description");
        const [activeTabNew, setActiveTabNew] = useState("vp");
        const [combinationKey, setCombinationKey] = useState(null);
        const [showFullText, setShowFullText] = useState(500);
        const [updated, setUpdated] = useState(false);
        const [isVisible, setIsVisible] = useState(false);
    
        const lightGallery = useRef(null);
        const getItems = useCallback(() => {
            return galleryI.map((item, index) => {
                return (
                    <a
                        key={index}
                        data-lg-size={item}
                        className="gallery-item"
                        data-src={item}
                    >
                        <img
                            style={{maxWidth: "80px"}}
                            className="img-responsive"
                            src={item}
                            alt={`Image ${index}`}
                        />
                    </a>
                );
            });
        }, [galleryI]);
    
        // method
        const addToCart = (pro_slug) => {
            if (!isLogin) {
                navigate("/login");
                return;
            }
    
            // const isVariationSelected = !inDetails
            //     || !inDetails.variation
            //     || inDetails.variation.every((variation, index) => {
            //         const selectedOption = selectedRadio[index];
            //         return (selectedOption && variation.values.find((val) => val.attr_value_id === selectedOption)?.attr_value_id === selectedOption);
            //     });
    
            const isProductHasVariations = !Array.isArray(
                singleProduct?.product_variations?.combinations
            );
    
            console.log("isProductHasVariation: ", isProductHasVariations);
    
            if (isProductHasVariations) {
                // Send with variations
                dispatch(
                    AddToCart({
                        pro_slug,
                        user_id,
                        product_id: singleProduct.product?.id,
                        quantity: prodQty,
                        selectedAttributes,
                        sku: singleProduct?.product_variations?.combinations[combinationKey]
                            ?.sku,
                        color: selectedColor,
                        test: "variation request",
                    })
                )
    
                toast('Cart update successfull!');
            } else {
                // Without Variations
                dispatch(
                    AddToCart({
                        pro_slug,
                        quantity: prodQty,
                        user_id,
                        product_id: singleProduct.product?.id,
                        test: "without variation request",
                    })
                )
    
                toast('Cart update successfull!');
    
            }
    
            getHeaderData({user_id});
        };
        const incrementProdQuantity = () => {
            if (prodQty < dbQuantity) {
                setProdQty((prev) => prev + 1);
                setButtonShouldDisable(false);
                console.log("prodQty after increment: ", prodQty);
            } else {
                setButtonShouldDisable(true);
            }
        };
        const decrementProdQuantity = () => {
            setProdQty((prev) => (prev > 1 ? prev - 1 : prev));
            console.log("prodQty after decrement: ", prodQty);
        };
    
        console.log(storeInfoTab);
        const handleTabChange = (tab) => setActiveTab(tab);
        const handleTabChangeNew = (tab) => setActiveTabNew(tab);
        const handleOrderClick = (vendor_id, shipping_profile) => {
            navigate(`/store/${storeInfoTab?.vendor?.store_slug}`, {
                state: {
                    vendor_id: vendor_id,
                    shipping_profile: shipping_profile,
                },
            });
        };
        const handleScrollToTop = () =>
            window.scrollTo({top: 0, behavior: "smooth"});
        const addToWishList = (product_id, index) => {
            dispatch(addWishlist(product_id));
    
            let heartIcon = document.getElementById("heartIcon-" + index);
            heartIcon.classList.toggle("selected");
            heartIcon.classList.toggle("hearticoncolor");
        };
        const addToWishListWithoutIndex = (product_id) => {
            dispatch(addWishlist(product_id));
    
            let heartIcon = document.getElementById("heartIconWithoutIndex");
            heartIcon.classList.toggle("selected");
            heartIcon.classList.toggle("hearticoncolor");
        };
    
        console.log("selectedAttributes", selectedAttributes)
    
        const handleAttributeChange = (attributeId, value) => {
            console.log(attributeId, value);
            setSelectedAttributes((prevAttributes) => {
                const attributeIndex = prevAttributes.findIndex(
                    (attr) => attr.id === attributeId
                );
    
                const updatedAttributes = [...prevAttributes];
    
                if (attributeIndex !== -1) {
                    updatedAttributes[attributeIndex].value = value;
                } else {
                    updatedAttributes.push({id: attributeId, value});
                }
                updatedAttributes.sort((a, b) => {
                    const aIndex =
                        singleProduct.product_variations?.choice_attributes_combination.findIndex(
                            (attr) => attr.id === a.id
                        );
                    const bIndex =
                        singleProduct.product_variations?.choice_attributes_combination.findIndex(
                            (attr) => attr.id === b.id
                        );
                    return aIndex - bIndex;
                });
                return updatedAttributes;
            });
        };
        const handleColorChange = (color) => setSelectedColor(color);
        const handleRadioChange = (value, i, inventory_id, id) => {
            const allLabels = document.querySelectorAll("label");
            allLabels.forEach((label) => {
                const invValue = label.getAttribute("data-inv");
                if (invValue === inventory_id) {
                    label.classList.remove("hide");
                } else {
                    label.classList.add("hide");
                }
            });
    
            const newSelectedRadio = [...selectedRadio];
            newSelectedRadio[i] = value;
            setSelectedRadio(newSelectedRadio);
            arr[i] = value;
            if (arr.length > 1) Object.keys(arr).sort();
            setArr(arr);
            let data = Object.values(arr).toString().replaceAll(",", "");
        };
    
        // use Effect
        useEffect(() => {
            dispatch(getSingleProductDetail({prodSlug}));
            dispatch(getCartData(true));
    
            const cartItemsData = [];
    
            cartData?.map((data) => {
                data?.cart_items?.map((item) => {
                    cartItemsData.push(item);
                });
            });
    
            const itemExistInCart = cartItemsData.find(
                (item) => item.pro_sku === "" && item.pro_slug === prodSlug
            );
            if (itemExistInCart) {
                setProdQty(itemExistInCart.quantity);
            } else {
                setProdQty(1);
            }
        }, [prodSlug]);
        useEffect(() => {
            (async () => {
                if (singleProduct) {
                    await dispatch(
                        getVendorInfo(
                            singleProduct?.product?.vendor_id,
                            singleProduct?.product?.shipping_profile.id
                        )
                    );
    
                    if (user_id) {
                        await dispatch(
                            getRelatedProducts(
                                singleProduct?.product?.id,
                                singleProduct?.product?.subcate_ids,
                                user_id
                            )
                        );
                        setDbQuantity(singleProduct?.product?.stock);
                    }
                }
            })();
        }, [singleProduct?.product]);
        useEffect(() => {
            variantData = {};
            singleProduct?.product &&
            Object.entries(singleProduct?.product.varients).map(([varient]) => {
                variantData = {...variantData, [varient]: ""};
            });
    
            setStockVal(singleProduct?.product && singleProduct?.product.stock);
            setRegularPrice(
                singleProduct?.product && singleProduct?.product?.regular_price
            );
            setSellPrice(singleProduct?.product && singleProduct?.product?.sell_price);
        }, [singleProduct?.product]);
        useEffect(() => {
            if (user_id && product_id) {
                dispatch(getProductCartCount(user_id, product_id));
            }
        }, [product_id]);
        useEffect(() => {
            setDbQuantity(userCartProductCount);
        }, [userCartProductCount]);
        useEffect(() => {
            if (wish === 1) {
                let element = document.getElementsByClassName("wish-class")[0];
                if (element) {
                    element.style.color = "red";
                }
            }
            if (wish === 0) {
                let element = document.getElementsByClassName("wish-class")[0];
                if (element) {
                    element.style.color = "#ffc107";
                }
            }
        }, [wish]);
        useEffect(() => {
            if (selectedAttributes) {
                let combinationKey = "";
                if (selectedAttributes?.length === 0) {
                    combinationKey += selectedColor;
                } else {
                    combinationKey += selectedColor + "-";
                }
    
                combinationKey += `${selectedAttributes
                    .map((attr) => attr.value)
                    .join("-")}`;
                setCombinationKey(combinationKey);
                console.log("combinationKey: ", combinationKey);
    
                const cartItemsData = [];
    
                cartData?.map((data) => {
                    data?.cart_items?.map((item) => {
                        cartItemsData.push(item);
                    });
                });
    
                const itemExistInCart = cartItemsData.find(
                    (item) => item.pro_sku === combinationKey
                );
                if (itemExistInCart) {
                    console.log("exist :", itemExistInCart);
                    setProdQty(itemExistInCart.quantity);
                } else {
                    setProdQty(1);
                }
    
                if (singleProduct?.product_variations?.combinations[combinationKey]?.qty) {
                    setDbQuantity(singleProduct?.product_variations?.combinations[combinationKey]?.qty);
                } else {
                    setDbQuantity(singleProduct?.product?.stock)
                }
    
                setUpdated(!updated);
    
                setUpdated(!updated);
            }
        }, [singleProduct?.product, selectedAttributes, selectedColor]);
        useEffect(() => {
            const initialAttributes =
                singleProduct?.product_variations?.choice_attributes_combination.map(
                    (attr) => ({
                        id: attr.id,
                        value: attr.values[0],
                    })
                );
            if (singleProduct?.product_variations?.colors) {
                let color = Object.entries(singleProduct?.product_variations?.colors)[0];
                if (color) {
                    setSelectedColor(color[1]);
                }
            }
            setSelectedAttributes(initialAttributes);
        }, [singleProduct?.product_variations]);
        useEffect(() => {
            if (statusKey || status) {
                setIsVisible(true);
    
                const timeout = setTimeout(() => {
                    setIsVisible(false);
                }, 2000);
    
                return () => clearTimeout(timeout);
            }
        }, [statusKey, status]);
    
        return (
            <>
                {st.loaderStatus ? (
                    <SiteLoader status={st.loaderStatus}/>
                ) : (
                    <>
                        <main>
                            <ToastContainer
                                position="bottom-center"
                                autoClose={1500}
                                transition={Slide}
                                hideProgressBar
                                pauseOnFocusLoss={false}
                                pauseOnHover={false}
                                theme="dark"
                            />
    
                            <div className="bg-light inner-breadcrumb">
                                <div className="container">
                                    <div className="breadcrumb-head">
                                        <h3>
                                            {singleProduct?.product?.pro_name.length > 20
                                                ? singleProduct?.product?.pro_name.slice(0, 20) + "..."
                                                : singleProduct?.product?.pro_name}
                                        </h3>
    
                                        <nav className="breadcrumb-wrap set-dec">
                                            <ol className="breadcrumb">
                          <span
                              className="breadcrumb-item active order-span"
                              aria-current="page"
                              order_id={singleProduct?.product?.id}
                              key={singleProduct?.product?.id}
                              onClick={() =>
                                  handleOrderClick(
                                      singleProduct?.product?.vendor_id,
                                      singleProduct.product?.shipping_profile?.id
                                  )
                              }
                              style={{
                                  cursor: "pointer",
                                  textDecoration: "none",
                              }}
                          >
                            <a>
                              <li
                                  className="morefromvendor"
                                  onClick={handleScrollToTop}
                              >
                                More from this vendor
                              </li>
                            </a>
                          </span>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                            </div>
    
                            <section className="single-wrapper section-wrapper">
                                <div className="container">
                                    <div className="row product-detail-wrap">
                                        <div className="col-md-5">
                                            <Modal
                                                show={modalImages?.length > 0 ? true : false}
                                                onHide={() => setModalImages([])}
                                                aria-labelledby="contained-modal-title-vcenter"
                                                centered
                                                size="xl"
                                            >
                                                <Modal.Body></Modal.Body>
                                                <ImageGallery
                                                    items={image}
                                                    showFullscreenButton={false}
                                                    showPlayButton={false}
                                                    showNav={true}
                                                    startIndex={imageIndex}
                                                    renderLeftNav={(onClick, disabled) => (
                                                        <button
                                                            className={`image-gallery-left-nav image-gallery-left-Position ${
                                                                disabled ? "disabled" : ""
                                                            }`}
                                                            onClick={onClick}
                                                            disabled={disabled}
                                                        >
                                                            {/* You can put your custom arrow icon here */}
                                                            <img
                                                                src={images["carousel-control-prev.png"]}
                                                                alt=""
                                                            />
                                                        </button>
                                                    )}
                                                    renderRightNav={(onClick, disabled) => (
                                                        <button
                                                            className={`image-gallery-right-nav image-gallery-right-Position ${
                                                                disabled ? "disabled" : ""
                                                            }`}
                                                            onClick={onClick}
                                                            disabled={disabled}
                                                        >
                                                            {/* You can put your custom arrow icon here */}
                                                            <img
                                                                src={images["carousel-control-next.png"]}
                                                                alt=""
                                                            />
                                                        </button>
                                                    )}
                                                />
                                            </Modal>
    
                                            {/*Gallery Start*/}
                                            <div className="zoom_product">
                                                {/*<ImageGallery items={images}/>*/}
                                                <ImageGallery
                                                    items={image}
                                                    showFullscreenButton={false}
                                                    showPlayButton={false}
                                                    showNav={true}
                                                    onSlide={(e) => setImageIndex(e)}
                                                    onClick={() => setModalImages(image)}
                                                    renderLeftNav={(onClick, disabled) => (
                                                        <button
                                                            className={`image-gallery-left-nav image-gallery-left-Position ${
                                                                disabled ? "disabled" : ""
                                                            }`}
                                                            onClick={onClick}
                                                            disabled={disabled}
                                                        >
                                                            {/* You can put your custom arrow icon here */}
                                                            <img
                                                                src={images["carousel-control-prev.png"]}
                                                                alt=""
                                                            />
                                                        </button>
                                                    )}
                                                    renderRightNav={(onClick, disabled) => (
                                                        <button
                                                            className={`image-gallery-right-nav image-gallery-right-Position ${
                                                                disabled ? "disabled" : ""
                                                            }`}
                                                            onClick={onClick}
                                                            disabled={disabled}
                                                        >
                                                            {/* You can put your custom arrow icon here */}
                                                            <img
                                                                src={images["carousel-control-next.png"]}
                                                                alt=""
                                                            />
                                                        </button>
                                                    )}
                                                />
                                            </div>
                                            {/* <!-- end  --> */}
                                        </div>
                                        <div className="col-md-5">
                                            <div className="product-detail ms-4 mt-2">
                                                {/*Product Title*/}
                                                <div className="d-flex justify-content-between">
                                                    <div className="detailProductName">
                                                        {singleProduct?.product?.pro_name}
                                                    </div>
                                                    <div>
                                                        <i
                                                            className={
                                                                singleProduct?.wishlist_status
                                                                    ? "fa fa-heart hearticoncolor selected wishlist-iconColor"
                                                                    : "fa fa-heart wishlist-iconColor"
                                                            }
                                                            aria-hidden="true"
                                                            wish-class="true"
                                                            id="heartIconWithoutIndex"
                                                            style={{cursor: "pointer"}}
                                                            onClick={(e) => {
                                                                e.stopPropagation();
                                                                addToWishListWithoutIndex(
                                                                    singleProduct.product?.id
                                                                );
                                                            }}
                                                        ></i>
                                                    </div>
                                                </div>
    
                                                {/*Review*/}
                                                <div className="review d-flex align-items-center">
                                                    <div>
                                                        <i
                                                            className="fa fa-star-o me-1"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <i
                                                            className="fa fa-star-o me-1"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <i
                                                            className="fa fa-star-o me-1"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <i
                                                            className="fa fa-star-o me-1"
                                                            aria-hidden="true"
                                                        ></i>
                                                        <i
                                                            className="fa fa-star-o me-1"
                                                            aria-hidden="true"
                                                        ></i>
                                                        {/* <i className="fa fa-star-half-o" aria-hidden="true"></i> */}
                                                    </div>
                                                    <span
                                                        className="grey-text detailProductReviews d-flex align-items-center mt-2">
                              <span>
                                {singleProduct?.rating_data?.total_rating}
                              </span>
                              <span style={{marginLeft: "5px"}}>Reviews</span>
                            </span>
                                                </div>
    
                                                {/*Price Tag*/}
                                                <div className="priceTag">
                                                    <span>&#x24;</span>
                                                    {combinationKey
                                                        ? singleProduct?.product_variations?.combinations[
                                                        combinationKey
                                                        ]?.price * prodQty
                                                        : singleProduct?.product?.sell_price * prodQty}
                                                </div>
    
                                                {/*Product Availability*/}
                                                <div className="available">
                                                    {(
                                                        combinationKey
                                                            ? !singleProduct?.product_variations?.combinations[
                                                                combinationKey
                                                                ]?.qty ||
                                                            singleProduct?.product_variations?.combinations[
                                                                combinationKey
                                                                ]?.display !== "on"
                                                            : singleProduct?.product?.stock === 0
                                                    ) ? (
                                                        <>
                                                            0 : <span className="text-red">Out of Stock</span>
                                                            &nbsp;&nbsp;
                                                            <span
                                                                className="order-span"
                                                                key={singleProduct?.product?.id}
                                                                style={{cursor: "pointer"}}
                                                            ></span>
                                                        </>
                                                    ) : (
                                                        <>
                                                            {singleProduct?.product?.stock !== 0 ||
                                                                singleProduct?.product_variations?.combinations[
                                                                    combinationKey
                                                                    ]?.qty}
                                                            {combinationKey
                                                                ? singleProduct?.product_variations?.combinations[
                                                                    combinationKey
                                                                    ]?.qty
                                                                : singleProduct?.product?.stock}
                                                            : <span className="text-green">In Stock</span>
                                                            &nbsp;&nbsp;
                                                            <span
                                                                className="order-span"
                                                                order_id={singleProduct?.product?.id}
                                                                key={singleProduct?.product?.id}
                                                                // onClick={() => handleOrderClick(singleProduct?.product?.vendor_id)}
                                                                style={{cursor: "pointer"}}
                                                            ></span>
                                                        </>
                                                    )}
                                                </div>
    
                                                {/*Product description*/}
                                                <p className="productDetailShortdes">
                                                    {singleProduct?.product?.short_desc}
                                                </p>
    
                                                {/*If Product has variations*/}
                                                {singleProduct?.product_variations && (
                                                    <div>
                                                        <table>
                                                            <tbody>
                                                            {/* Render color options */}
                                                            {singleProduct?.product_variations?.colors &&
                                                                Object.keys(
                                                                    singleProduct.product_variations.colors
                                                                ).length > 0 && (
                                                                    <tr>
                                                                        <td className={`button-column`}>
                                                                            <div className="d-flex">
                                                                                <div className="productDetailColor mt-1">
                                                                                    Colors
                                                                                </div>
                                                                                <div className=" ms-2">
                                                                                    <div className="d-flex">
                                                                                        {Object.keys(
                                                                                            singleProduct.product_variations
                                                                                                .colors
                                                                                        ).map((colorCode) => {
                                                                                            const colorName =
                                                                                                singleProduct.product_variations
                                                                                                    .colors[colorCode];
                                                                                            return (
                                                                                                <div
                                                                                                    style={{display: "flex"}}
                                                                                                    key={colorCode}
                                                                                                    className={
                                                                                                        selectedColor === colorName
                                                                                                            ? "color-selected color me-3"
                                                                                                            : "color me-3"
                                                                                                    }
                                                                                                >
                                                                                                    <button
                                                                                                        key={colorCode}
                                                                                                        id="variantFontSizeId"
                                                                                                        style={{
                                                                                                            backgroundColor:
                                                                                                            colorCode,
                                                                                                        }}
                                                                                                        onClick={() =>
                                                                                                            handleColorChange(
                                                                                                                colorName
                                                                                                            )
                                                                                                        }
                                                                                                    />
                                                                                                    {selectedColor ===
                                                                                                        colorName && (
                                                                                                            <i className="fa fa-check"></i>
                                                                                                        )}
                                                                                                </div>
                                                                                            );
                                                                                        })}
                                                                                    </div>
                                                                                    <span className="productDetailShortdes">
                                                {selectedColor}
                                              </span>
                                                                                </div>
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                )}
    
                                                            {/* Render attribute options */}
                                                            {singleProduct?.product_variations && (
                                                                <tr>
                                                                    {singleProduct?.product_variations?.choice_attributes_combination.map(
                                                                        (attribute, index) => (
                                                                            <td
                                                                                className="button-column mt-4"
                                                                                key={index}
                                                                            >
                                                                                <div
                                                                                    key={attribute.id}
                                                                                    className="d-flex align-items-center"
                                                                                >
                                                                                    <div className="productDetailColor">
                                                                                        {attribute.name}
                                                                                    </div>
                                                                                    <div
                                                                                        key={attribute.id}
                                                                                        style={{
                                                                                            display: "flex",
                                                                                            blockSize: "fit-content",
                                                                                        }}
                                                                                    >
                                                                                        {attribute.values.map((value) => (
                                                                                            <button
                                                                                                key={value}
                                                                                                onClick={() =>
                                                                                                    handleAttributeChange(
                                                                                                        attribute.id,
                                                                                                        value
                                                                                                    )
                                                                                                }
                                                                                                className={
                                                                                                    selectedAttributes &&
                                                                                                    selectedAttributes.some(
                                                                                                        (attr) =>
                                                                                                            attr.id ===
                                                                                                            attribute.id &&
                                                                                                            attr.value === value
                                                                                                    )
                                                                                                        ? "attribute-selected attribute-selectedIndex ms-2"
                                                                                                        : "attribute-selected ms-2"
                                                                                                }
                                                                                            >
                                                                                                {value}
                                                                                            </button>
                                                                                        ))}
                                                                                    </div>
                                                                                </div>
                                                                            </td>
                                                                        )
                                                                    )}
                                                                </tr>
                                                            )}
    
                                                            {/*Add to Cart Button*/}
                                                            <tr>
                                                                <td className=" d-flex mt-3">
                                                                    <div className="qty-style dataButton">
                                                                        <button
                                                                            onClick={() => decrementProdQuantity()}
                                                                        >
                                                                            <i className="fa fa-minus"></i>
                                                                        </button>
                                                                        <div>{prodQty}</div>
                                                                        <button
                                                                            onClick={() => incrementProdQuantity()}
                                                                        >
                                                                            <i className="fa fa-plus"></i>
                                                                        </button>
                                                                    </div>
                                                                    <button
                                                                        className="add-cart dataButtontwo"
                                                                        onClick={() =>
                                                                            addToCart(singleProduct.product?.pro_slug)
                                                                        }
                                                                        disabled={
                                                                            combinationKey
                                                                                ? singleProduct?.product_variations
                                                                                    ?.combinations[combinationKey]
                                                                                    ?.display !== "on" ||
                                                                                !singleProduct?.product_variations
                                                                                    ?.combinations[combinationKey]?.qty
                                                                                : !singleProduct?.product?.stock ||
                                                                                loader
                                                                        }
                                                                    >
                                                                        {loader ? (
                                                                            "Adding to cart..."
                                                                        ) : (
                                                                            <span className="data_textButton">
                                            <i
                                                className="fa fa-shopping-cart"
                                                aria-hidden="true"
                                            ></i>
                                            Add to Cart
                                          </span>
                                                                        )}
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                )}
    
                                                {/* Error */}
                                                <span id="v_msg"></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
    
                            <hr/>
    
                            {/*Description*/}
                            <section className="section-wrapper description">
                                <div className="container">
                                    <div className="desc-tab">
                                        <ul className="nav nav-tabs" id="desTab" role="tablist">
                                            {/*Description*/}
                                            <li className="nav-item" role="presentation">
                                                <button
                                                    className={`nav-link ${
                                                        activeTab === "description" ? "active" : ""
                                                    }`}
                                                    id="description-tab"
                                                    data-bs-toggle="tab"
                                                    data-bs-target="#description-tab-pane"
                                                    type="button"
                                                    role="tab"
                                                    aria-controls="description-tab-pane"
                                                    aria-selected={activeTab === "description"}
                                                    onClick={() => handleTabChange("description")}
                                                >
                                                    <i className="ri-dashboard-line"/> Description
                                                </button>
                                            </li>
    
                                            {/*Store*/}
                                            <li className="nav-item" role="presentation">
                                                <button
                                                    className={`nav-link ${
                                                        activeTab === "store" ? "active" : ""
                                                    }`}
                                                    id="store-tab"
                                                    data-bs-toggle="tab"
                                                    data-bs-target="#store"
                                                    type="button"
                                                    role="tab"
                                                    aria-controls="store"
                                                    aria-selected={activeTab === "store"}
                                                    onClick={() => handleTabChange("store")}
                                                >
                                                    <i className="ri-dashboard-line"/> Store Info
                                                </button>
                                            </li>
    
                                            {/*Shipping*/}
                                            <li className="nav-item" role="presentation">
                                                <button
                                                    className={`nav-link ${
                                                        activeTab === "shipping" ? "active" : ""
                                                    }`}
                                                    id="shipping-tab"
                                                    data-bs-toggle="tab"
                                                    data-bs-target="#shipping"
                                                    type="button"
                                                    role="tab"
                                                    aria-controls="shipping"
                                                    aria-selected={activeTab === "shipping"}
                                                    onClick={() => handleTabChange("shipping")}
                                                >
                                                    <i className="ri-dashboard-line"/> Shipping
                                                </button>
                                            </li>
                                        </ul>
    
                                        <div className="tab-content accordion" id="desTabContent">
                                            {/*Description*/}
                                            <div
                                                className={`tab-pane fade accordion-item ${
                                                    activeTab === "description" ? "active show" : ""
                                                }`}
                                                id="description-tab-pane"
                                                role="tabpanel"
                                                aria-labelledby="description-tab"
                                                tabIndex={0}
                                            >
                                                <div
                                                    id="description"
                                                    className="accordion-collapse collapse show d-lg-block"
                                                    aria-labelledby="description"
                                                    data-bs-parent="#desTabContent"
                                                >
                                                    <div className="accordion-body">
                                                        <div className="row">
                                                            <div className="col-md-4">
                                                                <div className="des-img">
                                                                    <img
                                                                        src={singleProduct?.product?.main_image}
                                                                        title=""
                                                                        alt=""
                                                                    />
                                                                </div>
                                                            </div>
    
                                                            <div className="col-md-6">
                                                                <div className="description-content">
                                                                    <h3>{singleProduct?.product?.pro_name}</h3>
    
                                                                    <p
                                                                        onClick={(e) => setShowFullText(-1)}
                                                                        style={{cursor: "pointer"}}
                                                                        dangerouslySetInnerHTML={{
                                                                            __html: fixChar(
                                                                                singleProduct?.product?.description,
                                                                                showFullText
                                                                            ),
                                                                        }}
                                                                    ></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                            {/*Store*/}
                                            <div
                                                className={`tab-pane fade accordion-item ${
                                                    activeTab === "store" ? "active show" : ""
                                                }`}
                                                id="store"
                                                role="tabpanel"
                                                aria-labelledby="store-tab"
                                            >
                                                <div
                                                    id="store"
                                                    className="accordion-collapse collapse show  d-lg-block"
                                                    aria-labelledby="store"
                                                    data-bs-parent="#desTabContent"
                                                >
                                                    <div className="accordion-body">
                                                        <div className="description-content">
                                                            {/* NEW three tabs added start */}
                                                            <div className="container">
                                                                <div className="d-flex">
                                                                    <div className="desc-tab desc-tabBG">
                                                                        <ul
                                                                            className="nav nav-tabs tm-tab d-flex flex-column"
                                                                            id="desTabnew"
                                                                            role="tablist"
                                                                        >
                                                                            {singleProduct?.product?.vendor
                                                                                ?.store_name && (
                                                                                <li
                                                                                    className="nav-item"
                                                                                    role="presentation"
                                                                                >
                                                                                    <button
                                                                                        className={`nav-link ${
                                                                                            activeTabNew === "vp"
                                                                                                ? "active"
                                                                                                : ""
                                                                                        }`}
                                                                                        aria-selected={activeTabNew === "vp"}
                                                                                        onClick={() =>
                                                                                            handleTabChangeNew("vp")
                                                                                        }
                                                                                    >
                                                                                        Vendor Information
                                                                                    </button>
                                                                                </li>
                                                                            )}
                                                                            {storeInfoTab?.vendor?.shipping_policy && (
                                                                                <li
                                                                                    className="nav-item"
                                                                                    role="presentation"
                                                                                >
                                                                                    <button
                                                                                        className={`nav-link ${
                                                                                            activeTabNew === "sp"
                                                                                                ? "active"
                                                                                                : ""
                                                                                        }`}
                                                                                        aria-selected={activeTabNew === "sp"}
                                                                                        onClick={() =>
                                                                                            handleTabChangeNew("sp")
                                                                                        }
                                                                                    >
                                                                                        Shipping Policy
                                                                                    </button>
                                                                                </li>
                                                                            )}
                                                                            {storeInfoTab?.vendor?.return_policy && (
                                                                                <li
                                                                                    className="nav-item"
                                                                                    role="presentation"
                                                                                >
                                                                                    <button
                                                                                        className={`nav-link ${
                                                                                            activeTabNew === "rt"
                                                                                                ? "active"
                                                                                                : ""
                                                                                        }`}
                                                                                        aria-selected={activeTabNew === "rt"}
                                                                                        onClick={() =>
                                                                                            handleTabChangeNew("rt")
                                                                                        }
                                                                                    >
                                                                                        Return Policy
                                                                                    </button>
                                                                                </li>
                                                                            )}
                                                                            {storeInfoTab?.vendor?.terms_conditions && (
                                                                                <li
                                                                                    className="nav-item"
                                                                                    role="presentation"
                                                                                >
                                                                                    <button
                                                                                        className={`nav-link ${
                                                                                            activeTabNew === "tc"
                                                                                                ? "active"
                                                                                                : ""
                                                                                        }`}
                                                                                        aria-selected={activeTabNew === "tc"}
                                                                                        onClick={() =>
                                                                                            handleTabChangeNew("tc")
                                                                                        }
                                                                                    >
                                                                                        Terms & Conditions
                                                                                    </button>
                                                                                </li>
                                                                            )}
                                                                        </ul>
                                                                    </div>
                                                                    <div className="vendorSide desc-tabBG">
                                                                        <div
                                                                            id="vp"
                                                                            className={`desc-tabBG tab-pane fade accordion-item text-alignment ${
                                                                                activeTabNew === "vp"
                                                                                    ? "active show"
                                                                                    : "hide"
                                                                            }`}
                                                                        >
                                                                            <div
                                                                                id="vp"
                                                                                className="accordion-collapse collapse show  d-lg-block"
                                                                                aria-labelledby="vp "
                                                                                data-bs-parent="#desTabContent"
                                                                            >
                                                                                <ul className="list-unstyled">
                                                                                    <li>
                                                                                        <strong>
                                                                                            {
                                                                                                singleProduct?.product?.vendor
                                                                                                    ?.full_name
                                                                                            }
                                                                                        </strong>
                                                                                    </li>
                                                                                    <li>
                                                                                        <strong>
                                                                                            {
                                                                                                singleProduct?.product?.vendor
                                                                                                    ?.store_name
                                                                                            }
                                                                                        </strong>
                                                                                    </li>
                                                                                    <li>
                                                                                        {" "}
                                                                                        <span
                                                                                            className="productDetailShortdesOne">
                                                {storeInfoTab?.vendor?.bio}
                                              </span>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                        <div
                                                                            id="sp"
                                                                            className={`desc-tabBG tab-pane fade accordion-item text-alignment manage-text ${
                                                                                activeTabNew === "sp"
                                                                                    ? "active show"
                                                                                    : "hide"
                                                                            }`}
                                                                        >
                                                                            <div
                                                                                id="sp"
                                                                                className="accordion-collapse collapse show  d-lg-block "
                                                                                aria-labelledby="sp "
                                                                                data-bs-parent="#desTabContent"
                                                                            >
                                                                                <p
                                                                                    className="productDetailShortdesOne"
                                                                                    dangerouslySetInnerHTML={{
                                                                                        __html: sanitizedTextThree,
                                                                                    }}
                                                                                ></p>
                                                                            </div>
                                                                        </div>
    
                                                                        <div
                                                                            id="rt"
                                                                            className={`desc-tabBG tab-pane fade accordion-item text-alignment manage-text ${
                                                                                activeTabNew === "rt"
                                                                                    ? "active show"
                                                                                    : "hide"
                                                                            }`}
                                                                        >
                                                                            <div
                                                                                id="rt"
                                                                                className="accordion-collapse collapse show  d-lg-block"
                                                                                aria-labelledby="rt "
                                                                                data-bs-parent="#desTabContent"
                                                                            >
                                                                                <p
                                                                                    className="productDetailShortdesOne"
                                                                                    dangerouslySetInnerHTML={{
                                                                                        __html: sanitizedText,
                                                                                    }}
                                                                                ></p>
                                                                                {/* <p className="productDetailShortdes">
                                              {sanitizedText}
                                            </p> */}
                                                                            </div>
                                                                        </div>
    
                                                                        <div
                                                                            id="tc"
                                                                            className={`desc-tabBG tab-pane fade accordion-item text-alignment manage-text ${
                                                                                activeTabNew === "tc"
                                                                                    ? "active show"
                                                                                    : "hide"
                                                                            }`}
                                                                        >
                                                                            <div
                                                                                id="tc"
                                                                                className="accordion-collapse collapse show  d-lg-block"
                                                                                aria-labelledby="tc "
                                                                                data-bs-parent="#desTabContent"
                                                                            >
                                                                                <p
                                                                                    className="productDetailShortdesOne"
                                                                                    dangerouslySetInnerHTML={{
                                                                                        __html: sanitizedTextTwo,
                                                                                    }}
                                                                                >
                                                                                    {/* {sanitizedTextTwo} */}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            {/* NEW three tabs added end */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
    
                                            {/*Shipping*/}
                                            <div
                                                className={`tab-pane fade accordion-item ${
                                                    activeTab === "shipping" ? "active show" : ""
                                                }`}
                                                id="shipping"
                                                role="tabpanel"
                                                aria-labelledby="shipping-tab"
                                            >
                                                <div
                                                    id="shipping"
                                                    className="accordion-collapse collapse show  d-lg-block"
                                                    aria-labelledby="shipping "
                                                    data-bs-parent="#desTabContent"
                                                >
                                                    <div className="accordion-body">
                                                        <div className="description-content row px-6">
                                                            <div className="col-md-6">
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Shipping profile Name</h6>
                                                                    <p className="color-class">
                                                                        {
                                                                            storeInfoTab?.shipping_info
                                                                                ?.shipping_profile_name
                                                                        }
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Standard Fee:</h6>
                                                                    <p className="color-class">
                                                                        {shippingDetails?.handling_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Additional Item Fee</h6>
                                                                    <p className="color-class">
                                                                        {shippingDetails?.additional_item_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Expedited Delivery Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.expedited_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Processing Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.processing_fee}
                                                                    </p>
                                                                </div>
                                                            </div>
    
                                                            <div className="col-md-6">
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Expedited Fee</h6>
                                                                    <p className="color-class">
                                                                        {shippingDetails?.expedited_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Additional Expedited Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.additional_expedited_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Processing Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.processing_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Gift Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.gift_packing_fee}
                                                                    </p>
                                                                </div>
    
                                                                <div
                                                                    className="d-flex gap-2 justify-content-between align-items-center mb-2 py-2  border-bottom border-1">
                                                                    <h6>Gift Packing Fee</h6>
                                                                    <p className="color-class">
                                                                        $ {shippingDetails?.gift_packing_fee}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
    
                            {/*Related Section*/}
                            <section
                                className={`section-wrapper featured bg-light ${
                                    relatedProducts?.length === 0 ? "hide" : ""
                                }`}
                            >
                                <div className="container footerpadding">
                                    <div
                                        className={`wrapper-header text-center mb-4 ${
                                            relatedProducts?.product?.length < 0 ? "hide" : ""
                                        }`}
                                    >
                                        {/*<h4 className="grey-text wow animated fadeInUp">More from this Seller</h4>*/}
                                        <div
                                            className="wow animated bestsellerproduct fadeInUp"
                                            data-wow-delay="0.3s"
                                        >
                                            Related Items
                                        </div>
                                        <p className="wow animated fadeInUp"></p>
                                    </div>
    
                                    {/* <!-- product  --> */}
                                    <div className="flex-product flexgrow">
                                        {relatedProducts.product?.map((rp, index) => {
                                            return (
                                                <div className="" key={index}>
                                                    <Link
                                                        to={`/shop/${rp.slug}/${rp.sub_cate_slug}/${rp.pro_slug}`}
                                                        className="item me-2  mb-3"
                                                    >
                                                        <div className="product-row wow shadow animated fadeInUp">
                                                            <div className="product-cover">
                                                                <img
                                                                    src={rp.main_image}
                                                                    className="img-fluid categoriy_img"
                                                                    title=""
                                                                    alt=""
                                                                />
                                                                <div className="wishlist-icon">
                                                                    <i
                                                                        className={
                                                                            rp?.status
                                                                                ? "fa fa-heart hearticoncolor selected"
                                                                                : "fa fa-heart"
                                                                        }
                                                                        aria-hidden="true"
                                                                        wish-class="true"
                                                                        id={`heartIcon-${index}`}
                                                                        style={{cursor: "pointer"}}
                                                                        onClick={(e) => {
                                                                            e.preventDefault();
                                                                            e.stopPropagation();
                                                                            addToWishList(rp.id, index);
                                                                        }}
                                                                    ></i>
                                                                </div>
                                                            </div>
    
                                                            {/* <!-- product-count  --> */}
                                                            <div className="product-content home-page-card p-3">
                                                                <div className="category_title">
                                                                    {rp.pro_name.length > 18
                                                                        ? rp.pro_name.slice(0, 18) + "..."
                                                                        : rp.pro_name}
                                                                </div>
    
                                                                <div className="categoryCartDes">
                                                                    <p
                                                                        dangerouslySetInnerHTML={{
                                                                            __html:
                                                                                rp.short_desc.length > 37
                                                                                    ? rp.short_desc.slice(0, 37) + "..."
                                                                                    : rp.short_desc,
                                                                        }}
                                                                    ></p>
                                                                </div>
                                                                <div className="price">
                                                                    <div className="grey-text">
                                      <span className="text-warning">
                                        ${rp.sell_price}
                                      </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            </section>
                        </main>
                    </>
                )}
            </>
        );
    };
    
    export default SingleProduct;
